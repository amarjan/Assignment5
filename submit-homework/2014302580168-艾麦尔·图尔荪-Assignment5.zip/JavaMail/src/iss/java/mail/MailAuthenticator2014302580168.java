package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
/**
 * 
 * @author amarjan tursun
 *
 */

public class MailAuthenticator2014302580168 extends Authenticator {
   /**
    * username
    */
    private String username;
   /**
    * password
    */
    private String password;

   
   /**
    *@param username
    *@param password
    **/
    public MailAuthenticator2014302580168(String username, String password) {
        this.username = username;
        this.password = password;
    }

    String getPassword() {
        return password;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

    String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
