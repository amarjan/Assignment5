package iss.java.mail;

//mport java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
/**
 * 
 * @author amarjan tursun
 *
 */
public class MailService2014302580168 implements IMailService {
	/*
	 * props
	 */
	private	 final Properties props =System.getProperties();
	/*
	 * session
	 */
	private transient Session session ;
	/*
	 * MailAuthenticator2014302580168
	 */
	private transient MailAuthenticator2014302580168 authenticator;
	 Store store = null;
	public MailService2014302580168() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		// final Properties props =System.getProperties();
		 props.put("mail.smtp.auth", "true");
		 props.put("mail.smtp.host","smtp.163.com");
		 authenticator=new MailAuthenticator2014302580168("crazyjack47@163.com","***********��");
		 session =Session.getInstance(props, authenticator);
	} 

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		final MimeMessage message =new MimeMessage(session);//mimemessage
		message.setFrom(new InternetAddress(authenticator.getUsername()));//senderaddress
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));//setreciption
		message.setSubject(subject);//setsubject
		message.setContent(content.toString(), "text/html;charset=utf-8");//setcontent
		Transport.send(message);	//send
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		props.put("mail.store.protocol", "pop3");
		props.put("mail.pop3.host", "pop3.163.com");
		authenticator=new MailAuthenticator2014302580168("crazyjack47@163.com","aiki52307456");
		session=Session.getInstance(props, authenticator);
		store=session.getStore();
		if(null !=store)
		return true;
		else return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		String getreply="no";
		store.connect();
		 Folder folder = store.getFolder("inbox");
	        folder.open(Folder.READ_ONLY);
	        Message[] messages = folder.getMessages();
	        int MailCounts=messages.length;
	        for(int i=0;i<MailCounts;i++){
	        	String Subject=messages[i].getSubject();
	        	String From=(messages[i].getFrom()).toString();
	        	  System.out.println("�� " + (i+1) + "���ʼ������⣺" + Subject);
	              System.out.println("�� " + (i+1) + "���ʼ��ķ����˵�ַ��" + From);
	     //    System.out.println("����򿪸��ʼ���(yes/no)?��");//open the mail text
	          //    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	            //  String input = br.readLine();
	           //   if("yes".equalsIgnoreCase(input)) {
	                  // ֱ�����������̨��
	                //  messages[i].writeTo(System.out);
	             // }
	              if("issjava2015".equalsIgnoreCase(From))
	            	  getreply="yes";
	          }
	          folder.close(false);
	          store.close();
	        	
	        

		
		return getreply;
		
	}

}
